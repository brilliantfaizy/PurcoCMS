<ul>
<li><a href="#"><img src="<?php echo "$base/images/paymentrecallIcon.png"; ?>"/><br />Payment<br />Recall</a></li>
<li><a href="#"><img src="<?php echo "$base/images/paymentlocalIcon.png"; ?>"/><br />Payment<br />Lock</a></li>
<li><a href="#"><img src="<?php echo "$base/images/paymentauditlogIcon.png"; ?>"/><br />Payment Audit<br />Log</a></li>

</ul>