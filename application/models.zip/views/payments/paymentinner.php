<ul>
<li><a <?php echo $innerMenuActive=="addpayment" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/PaymentController/addpayment">Add Payment</a></li>
<li><a <?php echo $innerMenuActive=="paymentorigin" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/PaymentController/paymentorigin">Add Payment Origin</a></li>
<li><a <?php echo $innerMenuActive=="payment" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/PaymentController/payment">Payment Summary</a></li>

</ul>