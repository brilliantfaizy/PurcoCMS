<?php $this->load->view('header'); ?>
<script>
	$().ready(function() {
	
		$("#signupForm").validate({
			rules: {
			
		
                permissions:{
                  required:true
                },
                pages:{
                  required:true
                }
			
			
			},
			messages: {
			
                permissions:"Select Roles must.",
                 pages:"Select Pages must."
                
			
              
			}
		});
	});
	</script>
	<style>

	
	#signupForm label.error {
	  display: table;
      color: red;
	}
    
    #signupForm input.error {
	  
      border: red;
	}

	</style>
<div id="content">
    <div id="innerMenu">

        <?php $this->load->view('admininner'); ?>

    </div>
    <div class="FormFields">

        <form id="signupForm" action="insertpages" method="post">

            <table class="FieldsTable" cellpadding="6">

                <tr>
                    <td>Page :</td>
                    <td>
                        <select name="pages" class="myfield">
                         <option value>Select</option>
                            <?php foreach($page_list as $row){?>
                            <option value="<?php  echo $row->Page_Id?>">
                                <?php echo $row->Page?></option>
                            <?php }?>
                  </select>
                    </td>
                    <td>Roles:</td>
                   <td>
                   <select name="permissions" class="myfield">
                    <option value>Select</option>
                            <?php foreach($perm_list as $row){?>
                            <option value="<?php  echo $row->RId?>">
                                <?php echo $row->RoleTitle?></option>
                            <?php }?>
                  </select>
                   </td>
                </tr>

                <tr>
                    <td colspan="4">
                        <input class="button medium BtnBlack" type="submit" name="submit" value="Insert Page" />
                    </td>

                </tr>



            </table>

        </form>

    </div>

    <div class="Grid">



        <table  cellspacing="0" cellpadding="10">

            <tr>
                <th style="width: 10%;">ID</th>
                <th style="width: 10%;">Page</th>
              <th style="width: 10%;">Role</th>
                <th style="width: 10%;">Action</th>

            </tr>

            <?php foreach($query as $student){ ?>

            <tr>

                <td>
                    <?php echo $student->PermPageId; ?></td>
                <td>
                    <?php echo $student->Page; ?></td>
                    
               <td>
                    <?php echo $student->RoleTitle; ?></td>

                <td><a href="viewupdatepage/<?php echo $student->PermPageId ?>">Edit</a>
                    <a href="deletepage/<?php echo $student->PermPageId ?>">Delete</a>
                </td>
            </tr>

            <?php } ?>



        </table>
    </div>

</div>
<?php $this->load->view('footer'); ?>