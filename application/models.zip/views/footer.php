
        <div id="footer"><p>Copyrights 2015. All Rights Reserved</p> </div>
        
        </div>
  
<script type="text/javascript" src="<?php echo "$base/script.js"; ?>"></script>
</body>
</html>