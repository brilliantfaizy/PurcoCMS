<?php $this->load->view('header'); ?>
<div id="content">

<div id="innerMenu">

        <?php $this->load->view('clientTabs'); ?>

    </div>
        
            <div class="FormFields">
                
                <form action="" method="post">
                
                    <table class="FieldsTable" cellpadding="6">
                        
                        <tr>
                            <td>Key :</td>
                            <td><input class="myfield" placeholder="" name="firstname" type="text" /></td>
                            
                            <td>Description :</td>
                             <td><input class="myfield" placeholder="" name="firstname" type="text" /></td>
                        </tr>
                        
                    
                            <tr>
                           
                             <td colspan="4">  <input class="button medium" type="submit" value="Add Client Type" /></td>
                                </tr>
                        
                    </table>
                
                </form>
                
            </div>
            
            <div id="innerTabs">
        
        
        <?php $this->load->view('ClientInnerTabs'); ?>

    </div>
            
            <div class="Grid">

        <table cellspacing="0" cellpadding="10">

            <tr>
                <th>Claim Name</th>
                <th>Code</th>
                <th>Region</th>
                <th>Last File</th>
                <th>Files/Month</th>
                <th>Last Journal</th>
                
            </tr>

            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr><tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
            
            <tr>
                <td>Claim Name</td>
                <td>Code</td>
                <td>Region</td>
                <td>Last File</td>
                <td>Files/Month</td>
                <td>Last Journal</td>
                
            </tr>
 

        </table>
    </div>
            
            </div>
            
            <?php $this->load->view('footer'); ?>