<ul>
<li><a <?php echo $innerMenuActive=="getall" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/RegController/getall">Manage Users</a></li>

<li><a <?php echo $innerMenuActive=="getall2" ? "class=\"innerMenuActive\"" : ""; ?>  href="<?php echo $base; ?>/index.php/RoleController/getall2">Manage Role</a></li>

<li><a <?php echo $innerMenuActive=="Getallrecord" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/PagesController/Getallrecord">Menu Permission</a></li>



</ul>