<?php $this->load->view('header'); ?>
<div id="content">



    <div class="Grid">



        <table style="width: 100%;" cellspacing="0" cellpadding="10">


            <tr>
                
                <th>No</th>
                <th>Province*</th>
                <th>PD*</th>
                <th>BI*</th>
                <th>Written* Contract</th>
                <th>Promissory* Note</th>
                <th>Med Pay* Subro</th>
                <th>PIP* Subro</th>
                <th>Med Pay/PIP Comments*</th>
               
            </tr>

             <tr>
                
                <td>1</td>
                <td>AA</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
               
            </tr>
            
             <tr>
                
                 <td>2</td>
                <td>AE</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
               
            </tr>
            
             <tr>
                
                 <td>3</td>
                <td>AP</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
               
            </tr>
             <tr>
                
                <td>4</td>
                <td>Alamaba</td>
                <td>2 Years</td>
                <td>6 Years</td>
                <td>6 Years</td>
                <td>4 Years</td>
                <td>Yes</td>
                <td>No</td>
                <td></td>
               
            </tr>
            
           <tr>
                
                <td>5</td>
                <td>American Samoa</td>
                <td>2 Years</td>
                <td>2 Years</td>
                <td>3 Years</td>
                <td>3 Years</td>
                <td>Yes</td>
                <td>No</td>
                <td></td>
               
            </tr>
             <tr>
                
                <td>6</td>
                  <td>Arizona</td>
                  <td>2 Years</td>
                <td>2 Years</td>
                <td>3 Years</td>
                <td>3 Years</td>
                <td>No</td>
                <td>No</td>
                <td>If you record a lien in the amount of $50,000 you can then recover any amount</td>
               
            </tr> <tr>
                
                 <td>7</td>
                <td>Arkansas</td>
                 <td>2 Years</td>
                <td>2 Years</td>
                <td>6 Years</td>
                <td>6 Years</td>
                <td>Yes</td>
                <td>Yes</td>
                <td></td>
               
            </tr>
            <tr>
                
                 <td>8</td>
                <td>California</td>
                <td>2 Years</td>
                <td>2 Years</td>
                <td>5 Years</td>
                <td>5 Years</td>
                <td>Yes</td>
                <td>No</td>
                <td>Lien on insured's T/P settlement</td>
               
            </tr>
            <tr>
                
                 <td>9</td>
                <td>Colorado</td>
                  <td>2 Years</td>
                <td>2 Years</td>
                <td>3 Years</td>
                <td>3 Years</td>
                <td>No</td>
                <td>No</td>
                <td></td>
               
            </tr>
           
        </table>
    </div>

</div>
<?php $this->load->view('footer'); ?>