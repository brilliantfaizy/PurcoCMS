<ul>

<li><a <?php echo $innerMenuActive=="disbursmentinfo" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/DisbursmentController/disbursmentinfo">Claim & Disbursment Information</a></li>
<li><a <?php echo $innerMenuActive=="disbursmentpayment" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/DisbursmentController/disbursmentpayment">Payment Information</a></li>
</ul>