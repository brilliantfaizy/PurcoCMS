<?php $this->load->view('header'); ?>
<div id="content">

    <div id="innerMenu">

        <?php $this->load->view('claims/ClaimModalMenu'); ?>

    </div>

    <div class="FormFields">

        <form action="" method="post">
            
            <table class="FieldsTable" cellpadding="6">

                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>Location Name:</td>
                    <td>
                        <label>PurCo abc</label>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>DOL</td>
                    <td>2/12/2012</td>
                    <td>clock Calender Notebook folder</td>

                </tr>

                <tr>
                    <td>Rental Agreement#:</td>
                    <td>AFB56</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Rental Location:</td>
                    <td>1-Hot</td>
                    <td></td>

                </tr>

                <tr>
                    <td>Renter:</td>
                    <td>
                        <label>PurCo abc</label>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Status:</td>
                    <td>ABc</td>
                    <td></td>

                </tr>

                <tr>
                    <td>Phone Number:</td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Year Make Model:</td>
                    <td>$345.00</td>
                    <td></td>


                </tr>
                <tr>
                    <td>Fax:</td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Vehical:</td>
                    <td>XX-Purco</td>
                    <td></td>


                </tr>
                <tr>
                    <td>Email:</td>
                    <td>abc@abc.com</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>LDW Status:</td>
                    <td>LDW</td>
                    <td></td>


                </tr>

                <tr>
                    <td></td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Specialist:</td>
                    <td>Jennifer Turner</td>
                    <td></td>


                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td></td>
                    <td></td>
                    <td>Note</td>


                </tr>

            </table>

            <div id="menu2" style="color: white;font-size: large;">
                <ul>
                    <li><a href="#">Amount</a></li>
                    <li><a href="#">Payment</a></li>
                    <li><a href="#">Disbursment</a></li>
                </ul>
            </div>

            <table class="FieldsTable" cellpadding="7" cellpadding="4">

                <tr>
                    <td>Type</td>
                    <td>
                        <select class="myfield"></select>
                    </td>
                    <td>Original</td>
                    <td>
                        <input type="text" class="myfield" />
                    </td>
                </tr>
                <tr>
                    <td>Billing</td>
                    <td>
                        <input type="text" class="myfield" />
                    </td>
                    <td>Negotiated</td>
                    <td>
                        <input type="text" class="myfield" />
                    </td>
                    <td>
                        <input type="button" class="medium button" value="Save" />
                    </td>
                </tr>
            </table>

            <div >
                <br/>
                <br/>
                <div style="width: 51%;">Amounts</div>
                <div style="width: 20%;margin: -2% 0% 0% 49%;">Projected</div>
                <div style="width: 15%;margin: -2% 0% 0% 78%;">Actual</div>
                <br />
            </div>


          



        </form>
    </div>
    
      <div class="FormFields">
                <table class="FieldsTable" cellpadding="7" style="width: 100%;">
                    <tr>
                        <th>Type</th>
                        <th>Original</th>
                        <th>Billing</th>
                        <th>Negotiate</th>
                        <th></th>
                        <th>To Client</th>
                        <th>To Purco</th>
                        <th>Received</th>
                        <th>To Client</th>
                        <th>To Purco</th>
                    </tr>
                    <tr>
                        <td>abc</td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td><a href="">X</a></td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                    </tr>
                    <tr>
                        <td>abc</td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td><a href="">X</a></td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                    </tr>
                    <tr>
                        <td>abc</td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td><a href="">X</a></td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                    </tr>
                    <tr>
                        <td>abc</td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td><a href="">X</a></td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                    </tr>
                    <tr>
                        <td>abc</td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td><a href="">X</a></td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                    </tr>
                    <tr>
                        <th>Total</th>
                        <th>$0.00</th>
                        <th>$0.00</th>
                        <th>$0.00</th>
                        <th></th>
                        <th>$0.00</th>
                        <th>$0.00</th>
                        <th>$0.00</th>
                        <th>$0.00</th>
                        <th>$0.00</th>
                    </tr>
                </table>
                <div >
                    <br/>
                    <br/>
                    <div style="width: 51%;">Amounts</div>
                    <div style="width: 20%;margin: -2% 0% 0% 49%;">Projected</div>
                    <div style="width: 15%;margin: -2% 0% 0% 78%;">Actual</div>
                    <br />
                </div>

            </div>
            <div class="FormFields">
                <table class="FieldsTable" cellpadding="7" style="width: 100%;">
                    <tr>
                        <th>Type</th>
                        <th>Original</th>
                        <th>Billing</th>
                        <th>Negotiate</th>
                        <th></th>
                        <th>To Client</th>
                        <th>To Purco</th>
                        <th>Received</th>
                        <th>To Client</th>
                        <th>To Purco</th>
                    </tr>
                    <tr>
                        <td>abc</td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td><a href="">X</a></td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                    </tr>
                    <tr>
                        <td>abc</td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td><a href="">X</a></td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                    </tr>
                    <tr>
                        <td>abc</td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td><a href="">X</a></td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                    </tr>
                    <tr>
                        <td>abc</td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td><a href="">X</a></td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                    </tr>
                    <tr>
                        <td>abc</td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td><a href="">X</a></td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>
                            <input type="text" name="" style="width: 50%;" class="myfield" />
                        </td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                        <td>$0.00</td>
                    </tr>
                    <tr>
                        <th>Total</th>
                        <th>$0.00</th>
                        <th>$0.00</th>
                        <th>$0.00</th>
                        <th></th>
                        <th>$0.00</th>
                        <th>$0.00</th>
                        <th>$0.00</th>
                        <th>$0.00</th>
                        <th>$0.00</th>
                    </tr>
                </table>

            </div>

</div>