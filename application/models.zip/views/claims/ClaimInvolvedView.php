<?php $this->load->view('header'); ?>
<div id="content">

           <div id="innerMenu">
            
            <?php $this->load->view('claims/ClaimModalMenu'); ?>
        
        </div>

    <div class="FormFields">

        <form action="" method="post">
            
            <table class="FieldsTable"  cellpadding="6">

                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>Location Name:</td>
                    <td>
                        <label>PurCo abc</label>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>DOL</td>
                    <td>2/12/2012</td>
                    <td>clock Calender Notebook folder</td>

                </tr>

                <tr>
                    <td>Rental Agreement#:</td>
                    <td>AFB56</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Rental Location:</td>
                    <td>1-Hot</td>
                    <td></td>

                </tr>

                <tr>
                    <td>Renter:</td>
                    <td>
                        <label>PurCo abc</label>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Status:</td>
                    <td>ABc</td>
                    <td></td>

                </tr>

                <tr>
                    <td>Phone Number:</td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Year Make Model:</td>
                    <td>$345.00</td>
                    <td></td>


                </tr>
                <tr>
                    <td>Fax:</td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Vehical:</td>
                    <td>XX-Purco</td>
                    <td></td>


                </tr>
                <tr>
                    <td>Email:</td>
                    <td>abc@abc.com</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>LDW Status:</td>
                    <td>LDW</td>
                    <td></td>


                </tr>

                <tr>
                    <td></td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Specialist:</td>
                    <td>Jennifer Turner</td>
                    <td></td>


                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td></td>
                    <td></td>
                    <td>Note</td>


                </tr>

                <tr>
                    <td></td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td></td>
                    <td></td>
                    <td></td>


                </tr>
                <tr>
                    <td>
                        <input type="button" class="medium button BtnBlack" value="New Party" />
                    </td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td></td>
                    <td>
                        <div style="background-color: red;width: 20%;font-size: medium;padding: 0% 7%;">I</div>Insurance</td>
                    <td>
                        <div style="background-color: red;width: 20%;font-size: medium;padding: 0% 7%;">E</div>Employer</td>
                    <td>
                        <div style="background-color: red;width: 8%;font-size: medium;padding: 0% 7%;">C</div>Credit Card</td>
                    <td>
                        <div style="background-color: red;width: 22%;font-size: medium;padding: 0% 7%;">A</div>Attorney</td>


                </tr>
            </table>
            

                <table class="FieldsTable" cellpadding="6">

                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <th>Renter</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>Roland</th>
                        <th></th>
                        <th>Abc@abc.com</th>

                    </tr>

                    <tr>
                        <th>Home Address</th>
                        <td>123 abc Street 123 anywhere 1267 </td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td></td>

                    </tr>

                    <tr>
                        <td>Day Phone:</td>
                        <td>
                            <label>52435624356</label>
                        </td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td></td>

                    </tr>

                    <tr>
                        <td>Mobile Phone:</td>
                        <td>
                            <label>52435624356</label>
                        </td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td></td>



                    </tr>
                    <tr>
                        <td>Night Phone:</td>
                        <td>
                            <label>52435624356</label>
                        </td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td></td>



                    </tr>
                    <tr>
                        <th>
                            <div style="background-color: red;width: 8%;font-size: medium;padding: 0% 7%;">C</div>
                        </th>
                        <th>Visa Card Benifits Services</th>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td></td>


                    </tr>

                    <tr>
                        <td>-Phone#:</td>
                        <td>0800-6567567 -Fax#:04345354 -Address:123 gdgf 657 hh</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td></td>


                    </tr>
                    <tr>
                        <td>Keniya Randol</td>
                        <td>-Phone#:0800-6567567 -Fax#:04345354 -Address:123 gdgf 657 hh</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td></td>
                        <td></td>
                        <td></td>


                    </tr>
                    <tr>
                        <th>
                            <div style="background-color: red;width: 8%;font-size: medium;padding: 0% 7%;">A</div>
                        </th>
                        <th>Dewev. Hayew</th>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td></td>


                    </tr>

                    <tr>
                        <td>-Phone#:</td>
                        <td>0800-6567567 -Fax#:04345354 -Address:123 gdgf 657 hh</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td></td>


                    </tr>
                    <tr>
                        <td>Sample Attorney</td>
                        <td>-Phone#:0800-6567567 -Fax#:04345354 -Address:123 gdgf 657 hh</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td></td>
                        <td></td>
                        <td></td>


                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td></td>
                        <td></td>
                        <td>
                            <select class="myfield">
                                <option>Select</option>
                            </select>
                        </td>


                    </tr>
                </table>

            

           
                <table class="FieldsTable" cellpadding="6">

                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr>
                        <th>Client</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>Sample Client</th>
                        <th></th>
                        <th></th>

                    </tr>

                    <tr>
                        <th>Home Address</th>
                        <td>123 abc Street 123 anywhere 1267 </td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td>&nbsp;&nbsp;&nbsp;</td>
                        <td></td>

                    </tr>
                </table>
            </div>




        </form>
    </div>

</div>