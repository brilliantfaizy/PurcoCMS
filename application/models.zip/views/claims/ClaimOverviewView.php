<?php $this->load->view('header'); ?>
<div id="content">

           <div id="innerMenu">
            
            <?php $this->load->view('claims/ClaimModalMenu'); ?>
        
        </div>
       
            <div class="FormFields">
            
                <form action="" method="post">
           
        <table class="FieldsTable" cellpadding="6">
                       
                        <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
                        <tr>
                            <td>Client:</td>
                            <td><label>PurCo abc</label></td>
                            <td>Status</td>
                            <td>Open and being Worked</td>
                             <td>clock  Calender Notebook folder</td>
                             
                              </tr>
                        
                        <tr>
                            <td>Client Claim#:</td>
                            <td><input class="myfield" placeholder="" style="width: 50%;" name="firstname" type="text" /></td>
                            <td>Priority</td>
                            <td>1-Hot</td>
                             <td></td>
                             
                              </tr>
                        
                         <tr>
                            <td>Contact:</td>
                            <td><label>PurCo abc</label></td>
                            <td>Loss Location</td>
                            <td><input class="myfield" placeholder="" style="width: 50%;" name="firstname" type="text" /></td>
                             <td>None</td>
                             
                              </tr>
                        
                         <tr>
                             <td>Day Phone:</td>
                             <td></td>
                            <td>Amount Due:</td>
                              <td>$345.00</td>
                             <td></td>
                       
                             
                        </tr>
                         <tr>
                             <td>Fax:</td>
                             <td></td>
                            <td>Location:</td>
                              <td>XX-Purco</td>
                             <td></td>
                       
                             
                        </tr>
                          <tr>
                             <td>Email:</td>
                             <td></td>
                            <td>Specialist:</td>
                              <td>Jennifer Turner</td>
                             <td></td>
                       
                             
                        </tr>
                      
                          <tr>
                             <td>DOL:</td>
                             <td>2/12/2012</td>
                            <td>Renter:</td>
                              <td><a href="">Roland Renter</a></td>
                             <td></td>
                       
                             
                        </tr>
                         <tr>
                             <td>Received:</td>
                             <td>2/12/2012</td>
                            <td></td>
                              <td></td>
                             <td></td>
                       
                             
                        </tr>
                         <tr>
                             <td>Completed:</td>
                             <td>2/12/2012  Lost Days: 2</td>
                            <td></td>
                              <td></td>
                             <td></td>
                       
                             
                        </tr>
                        
                         <tr>
                             <td>Vehicle #:</td>
                             <td>AXC-027</td>
                            <td>LDW Status</td>
                              <td><select name="status" style="width: 50%;" class="myfield"></select></td>
                             <td></td>
                       
                             
                        </tr>
                          <tr>
                             <td>Renter Agreement #:</td>
                             <td>DN-4334</td>
                            <td>Police Report#:</td>
                              <td><input class="myfield" placeholder="" style="width: 50%;" name="firstname" type="text" /></td>
                             <td></td>
                       
                             
                        </tr>
                        <tr>
                             <td>Disputed:</td>
                             <td><input type="checkbox" name="ch3"/></td>
                            <td>Renter Card Type:</td>
                              <td><select name="status" style="width: 50%;" class="myfield"></select></td>
                             <td></td>
                       
                             
                        </tr>
                        <tr>
                             <td>FDCPA:</td>
                             <td><input type="checkbox" name="ch3"/></td>
                            <td></td>
                              <td></td>
                             <td></td>
                       
                             
                        </tr>
                        <tr> 
                        <td></td>
                             <td></td>
                              
                           <td colspan="5">
                            <input class="button medium BtnBlack" type="submit" value="Add Note" />
                                
                            </td>
                       </tr>
                    
                    </table>
                    
                </form>
                
            </div>
            
            <div class="Grid">
                     <table cellspacing="0" cellpadding="10">
                    
                    <tr>
                    <th></th>
                        <th>Type</th>
                        <th>Posted By</th>
                        <th>Date</th>
                        <th>Note</th>
                        
                       
                      
                        
                    </tr>
                    
                     <tr>
                     <td><div style="background-color: yellow;width:15px;">C</div></td>
                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email Address</td>
                        <td>Validity to</td>
                        
                      
                     </tr>
                      <tr>
                     <td><div style="background-color: yellow;width:15px;">C</div></td>
                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email Address</td>
                        <td>Validity to</td>
                        
                      
                     </tr>
                        <tr>
                     <td><div style="background-color: red;width:15px;">P</div></td>
                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email Address</td>
                        <td>Validity to</td>
                        
                      
                     </tr>
                     <tr>
                     <td><div style="background-color: yellow;width:15px;">C</div></td>
                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email Address</td>
                        <td>Validity to</td>
                        
                      
                     </tr>
                   
                
                </table>
                    </div>
            
    
            
            </div>
            
  