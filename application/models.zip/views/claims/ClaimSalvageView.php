<?php $this->load->view('header'); ?>
<div id="content">

           <div id="innerMenu">
            
            <?php $this->load->view('claims/ClaimModalMenu'); ?>
        
        </div>

    <div class="FormFields">

        <form action="" method="post">
           
            <table class="FieldsTable" cellpadding="6">

                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>Location Name:</td>
                    <td>
                        <label>PurCo abc</label>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>DOL</td>
                    <td>2/12/2012</td>
                    <td>clock Calender Notebook folder</td>

                </tr>

                <tr>
                    <td>Rental Agreement#:</td>
                    <td>AFB56</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Rental Location:</td>
                    <td>1-Hot</td>
                    <td></td>

                </tr>

                <tr>
                    <td>Renter:</td>
                    <td>
                        <label>PurCo abc</label>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Status:</td>
                    <td>ABc</td>
                    <td></td>

                </tr>

                <tr>
                    <td>Phone Number:</td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Year Make Model:</td>
                    <td>$345.00</td>
                    <td></td>


                </tr>
                <tr>
                    <td>Fax:</td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Vehical:</td>
                    <td>XX-Purco</td>
                    <td></td>


                </tr>
                <tr>
                    <td>Email:</td>
                    <td>abc@abc.com</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>LDW Status:</td>
                    <td>LDW</td>
                    <td></td>


                </tr>

                <tr>
                    <td></td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Specialist:</td>
                    <td>Jennifer Turner</td>
                    <td></td>


                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td></td>
                    <td></td>
                    <td>Note</td>


                </tr>

            </table>

            <div id="menu2" style="color: white;font-size: large; width: 60%;">
                <ul>
                    <li><a href="#">Vehicle</a></li>
                    <li><a href="#">Purco Salvages</a></li>
                    <li><a href="#">Salvages Buyer</a></li>
                </ul>
            </div>


            <div style="float: left;">
                <table class="FieldsTable">
                    <tr>
                        <td>DOL:20/1/2015</td>
                    </tr>
                    <tr>
                        <td>Yr/Make:</td>
                        <td>
                            <select class="myfield" style="width:45%;"></select>
                        </td>
                        <td>Mileage:</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%;" />
                        </td>
                        <td>Exterior Color:</td>
                        <td>
                            <select class="myfield" style="width:45%;"></select>
                        </td>
                        <td>Interior Color:</td>
                        <td>
                            <select class="myfield" style="width:45%;"></select>
                        </td>
                        <td>Interior Type:</td>
                        <td>
                            <select class="myfield" style="width:45%;"></select>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <select class="myfield" style="width:45%;"></select>
                        </td>
                        <td>Engine:</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%;" />
                        </td>
                        <td>Pri. Damage:</td>
                        <td>
                            <select class="myfield" style="width:45%;"></select>
                        </td>
                        <td>Sec. Damage:</td>
                        <td>
                            <select class="myfield" style="width:45%;"></select>
                        </td>
                        <td>Flood Level:</td>
                        <td>
                            <select class="myfield" style="width:45%;"></select>
                        </td>
                    </tr>

                    <tr>
                        <td>Model:</td>
                        <td>
                            <select class="myfield" style="width:45%;"></select>
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>CD Player</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Pwr Windows</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Pwr Locks</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Alloy Wheels</td>
                    </tr>

                    <tr>
                        <td></td>
                        <td>
                            <input type="text" class="myfield" style="width:45%;" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Pwr Steering</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Tilt Steering</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>4 Wheel drive</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Curis Control</td>
                    </tr>

                    <tr>
                        <td>VIN</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%;" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Tape Desk</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Airbags Deployed</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Moon Roof</td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td>Title:</td>
                        <td>
                            <select class="myfield" style="width:45%;"></select>
                        </td>
                        <td>First Name/Last Name:</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%;" />
                        </td>
                        <td>
                            <input type="text" class="myfield" style="width:45%;" />
                        </td>
                        <td>
                            <input type="text" class="myfield" style="width:45%;" />
                        </td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td>Purco Salvages:</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Address:</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%" />
                        </td>
                        <td></td>
                        <td>Phone:</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%" />
                        </td>
                        <td></td>
                    </tr>

                    <tr>
                        <td>Sold:</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>City:</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%" />
                        </td>
                        <td></td>
                        <td>Fax:</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%" />
                        </td>
                        <td></td>
                    </tr>

                    <tr>
                        <td>Bookvalue:</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%;" />
                        </td>
                        <td>State:</td>
                        <td>
                            <select class="myfield" style="width:45%;"></select>
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td>Reserve Price:</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%;" />
                        </td>
                        <td>Zip:</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%;" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Date Sold:</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%;" />
                        </td>
                        <td>
                            <input type="button" class="medium button" value="Save To PurcoSalvages" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Final Sale:</td>
                        <td>
                            <input type="text" class="myfield" style="width:45%;" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Attachment:</td>
                        <td>
                            <input type="file" style="width:70%;" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <input type="text" class="myfield" style="width:70%;height: 100px;" />
                        </td>

                        <td></td>
                    </tr>
                    <tr>
                        <td>
                            <input type="button" class="medium button" value="Attach" />
                        </td>
                        <td>
                            <input type="button" class="medium button" value="Save" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </table>
            </div>
            <div>
                <table class="FieldsTable">
                    <tr>
                        <td>DOL:20/1/2015</td>
                    </tr>
                    <tr>
                        <td>Yr/Make:</td>
                        <td>
                            <select class="myfield" style="width:70%;"></select>
                        </td>
                        <td>Est. Amount:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>App. By:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>App Date:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <select class="myfield" style="width:70%;"></select>
                        </td>
                        <td>Sent:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Salvage#:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Reran:</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                    </tr>

                    <tr>
                        <td>Model:</td>
                        <td>
                            <select class="myfield" style="width:70%;"></select>
                        </td>
                        <td>Auction Start:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Auction Close:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Reserve:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                    </tr>

                    <tr>
                        <td></td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Sell App:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Sold Date:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Sale Price:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                    </tr>

                    <tr>
                        <td>VIN</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Payment Sent:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Payment Rec.:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Purco Fee:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                    </tr>

                    <tr>
                        <td>Title:</td>
                        <td>
                            <select class="myfield" style="width:70%;"></select>
                        </td>
                        <td>Check Date:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Check #:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Amount:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                    </tr>

                    <tr>
                        <td>Purco Salvages:</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Title Rec.:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%" />
                        </td>
                        <td>Pick Now:</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Proceed:</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                    </tr>

                    <tr>
                        <td>Sold:</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Title For:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Comment:</td>
                        <td colspan="2">
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                    </tr>

                    <tr>
                        <td>Bookvalue:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Who Pur.:</td>
                        <td>
                            <select class="myfield" style="width:70%;"></select>
                        </td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td>Reserve Price:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Date Sold:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Final Sale:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Attachment:</td>
                        <td>
                            <input type="file" style="width:70%;" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <input type="text" class="myfield" style="width:70%;height: 100px;" />
                        </td>

                        <td></td>
                    </tr>
                    <tr>
                        <td>
                            <input type="button" class="medium button" value="Attach" />
                        </td>
                        <td>
                            <input type="button" class="medium button" value="Save" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </table>
            </div>


            <div>
                <table class="FieldsTable">
                    <tr>
                        <td>DOL:20/1/2015</td>
                    </tr>
                    <tr>
                        <td>Yr/Make:</td>
                        <td>
                            <select class="myfield" style="width:70%;"></select>
                        </td>
                        <td>List Of Salvage Buyer:</td>
                        <td colspan="4" rowspan="2">
                            <input type="text" class="myfield" style="width:70%;height: 100px;" />
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <select class="myfield" style="width:70%;"></select>
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td>Model:</td>
                        <td>
                            <select class="myfield" style="width:70%;"></select>
                        </td>
                        <td>Business Name</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>First Name/Last Name:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%" />
                        </td>
                        <td>
                            <input type="text" class="myfield" style="width:70%" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td>VIN</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>Adress</td>
                        <td colspan="2">
                            <input type="text" class="myfield" style="width:70%" />
                        </td>

                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td>Title:</td>
                        <td>
                            <select class="myfield" style="width:70%;"></select>
                        </td>
                        <td>City/State/Zip:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td colspan="3">
                            <select class="myfield" style="width:50%;"></select>
                            <input type="text" class="myfield" style="width:40%;" />
                        </td>

                        <td>
                    </tr>

                    <tr>
                        <td>Purco Salvages:</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Phone:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%" />
                        </td>
                        <td>
                            <input type="text" class="myfield" style="width:70%" />
                        </td>
                        <td>Fax:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%" />
                        </td>
                        <td>
                    </tr>

                    <tr>
                        <td>Sold:</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>Email:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td></td>
                        <td colspan="2"></td>
                    </tr>

                    <tr>
                        <td>Bookvalue:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td>
                            <input type="button" class="medium button" value="New" />
                        </td>
                        <td>
                            <input type="button" class="medium button" value="Save" />
                        </td>
                        <td>
                            <input type="button" class="medium button" value="Delete" />
                        </td>
                        <td></td>
                    </tr>

                    <tr>
                        <td>Reserve Price:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Date Sold:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Final Sale:</td>
                        <td>
                            <input type="text" class="myfield" style="width:70%;" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Attachment:</td>
                        <td>
                            <input type="file" style="width:70%;" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <input type="text" class="myfield" style="width:70%;height: 100px;" />
                        </td>

                        <td></td>
                    </tr>
                    <tr>
                        <td>
                            <input type="button" class="medium button BtnBlack" value="Attach" />
                        </td>
                        <td>
                            <input type="button" class="medium button BtnBlack" value="Save" />
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </table>
            </div>

        </form>
    </div>

</div>