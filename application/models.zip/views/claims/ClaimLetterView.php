<?php $this->load->view('header'); ?>
<div id="content">

           <div id="innerMenu">
            
            <?php $this->load->view('claims/ClaimModalMenu'); ?>
        
        </div>
       
            <div class="FormFields">
            
               
                
        <table class="FieldsTable"  cellpadding="6">
                       
                        <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
                        <tr>
                            <td>Location Name:</td>
                            <td><label>PurCo abc</label></td>
                            <td>&nbsp;&nbsp;&nbsp;</td>
                            <td>&nbsp;&nbsp;&nbsp;</td>
                            <td>DOL</td>
                            <td>2/12/2012</td>
                             <td>clock  Calender Notebook folder</td>
                             
                              </tr>
                        
                        <tr>
                            <td>Rental Agreement#:</td>
                            <td>AFB56</td>
                             <td>&nbsp;&nbsp;&nbsp;</td>
                             <td>&nbsp;&nbsp;&nbsp;</td>
                            <td>Rental Location:</td>
                            <td>1-Hot</td>
                             <td></td>
                             
                              </tr>
                        
                         <tr>
                            <td>Renter:</td>
                            <td><label>PurCo abc</label></td>
                             <td>&nbsp;&nbsp;&nbsp;</td>
                             <td>&nbsp;&nbsp;&nbsp;</td>
                            <td>Status:</td>
                            <td>ABc</td>
                             <td></td>
                             
                              </tr>
                        
                         <tr>
                             <td>Phone Number:</td>
                             <td></td>
                              <td>&nbsp;&nbsp;&nbsp;</td>
                              <td>&nbsp;&nbsp;&nbsp;</td>
                            <td>Year Make Model:</td>
                              <td>$345.00</td>
                             <td></td>
                       
                             
                        </tr>
                         <tr>
                             <td>Fax:</td>
                             <td></td>
                              <td>&nbsp;&nbsp;&nbsp;</td>
                              <td>&nbsp;&nbsp;&nbsp;</td>
                            <td>Vehical:</td>
                              <td>XX-Purco</td>
                             <td></td>
                       
                             
                        </tr>
                          <tr>
                             <td>Email:</td>
                             <td>abc@abc.com</td>
                              <td>&nbsp;&nbsp;&nbsp;</td>
                              <td>&nbsp;&nbsp;&nbsp;</td>
                            <td>LDW Status:</td>
                              <td>LDW</td>
                             <td></td>
                       
                             
                        </tr>
                      
                          <tr>
                             <td></td>
                             <td></td>
                              <td>&nbsp;&nbsp;&nbsp;</td>
                              <td>&nbsp;&nbsp;&nbsp;</td>
                            <td>Specialist:</td>
                              <td>Jennifer Turner</td>
                             <td></td>
                       
                             
                        </tr>
                         <tr>
                             <td></td>
                             <td></td>
                              <td>&nbsp;&nbsp;&nbsp;</td>
                              <td>&nbsp;&nbsp;&nbsp;</td>
                            <td></td>
                              <td></td>
                             <td>Note</td>
                       
                             
                        </tr>
                       
                       
                       
                       
                    </table>
                      <div style="width: 45%;margin: 0% 0% 0% 4%;" > Involved <br />
                      <br />
                      <div style="background-color: rgb(224, 224, 224); width: 90%; height:200px"></div></div>
                    </div>
                     <div style="width: 45%;margin: -19% 5% 0% 46%;" > Letter <br />
                      <br />
                      <div style="background-color: rgb(224, 224, 224); width: 100%; height:200px"></div></div>
                    </div>