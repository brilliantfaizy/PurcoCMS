<?php $this->load->view('header'); ?>
<div id="content">

           <div id="innerMenu">
            
            <?php $this->load->view('claims/ClaimModalMenu'); ?>
        
        </div>

    <div class="FormFields">

        <form action="" method="post">
            
            <table class="FieldsTable" cellpadding="6">

                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>Location Name:</td>
                    <td>
                        <label>PurCo abc</label>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>DOL</td>
                    <td>2/12/2012</td>
                    <td>clock Calender Notebook folder</td>

                </tr>

                <tr>
                    <td>Rental Agreement#:</td>
                    <td>AFB56</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Rental Location:</td>
                    <td>1-Hot</td>
                    <td></td>

                </tr>

                <tr>
                    <td>Renter:</td>
                    <td>
                        <label>PurCo abc</label>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Status:</td>
                    <td>ABc</td>
                    <td></td>

                </tr>

                <tr>
                    <td>Phone Number:</td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Year Make Model:</td>
                    <td>$345.00</td>
                    <td></td>


                </tr>
                <tr>
                    <td>Fax:</td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Vehical:</td>
                    <td>XX-Purco</td>
                    <td></td>


                </tr>
                <tr>
                    <td>Email:</td>
                    <td>abc@abc.com</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>LDW Status:</td>
                    <td>LDW</td>
                    <td></td>


                </tr>

                <tr>
                    <td></td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>Specialist:</td>
                    <td>Jennifer Turner</td>
                    <td></td>


                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td></td>
                    <td></td>
                    <td>Note</td>


                </tr>




            </table>
            <table class="FieldsTable" cellpadding="6">
                <tr>
                    <td>
                        <input type="button" class="medium button" value="Save" />
                    </td>
                    <td>Date:</td>
                    <td>
                        <input type="text" class="myfield" />
                    </td>
                    <td>Time:</td>
                    <td>
                        <input type="text" class="myfield" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="button" class="medium button" value="Print" />
                    </td>
                    <td>Prewritten:</td>
                    <td>
                        <select name="status" class="myfield"></select>
                    </td>
                    <td>Viewable By:</td>
                    <td>
                        <select name="status" class="myfield"></select>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="button" class="medium button" value="Edit PDF" />
                    </td>
                    <td>General:</td>
                    <td>
                        <select name="status" class="myfield"></select>
                    </td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>
                        <input type="button" class="medium button" value="Delete" />
                    </td>
                    <td>Attachment:</td>
                    <td>
                        <input type="file" />
                    </td>
                    <td></td>
                    <td></td>
                </tr>
            </table>
            
        </form>

    </div>

<div class="Grid">
                <table cellspacing="0" cellpadding="10">

                    <tr>
                        <th></th>
                        <th>Type</th>
                        <th>Posted By</th>
                        <th>Date</th>
                        <th>Note</th>




                    </tr>

                    <tr>
                        <td>
                            <div style="background-color: yellow;width:15px;">C</div>
                        </td>
                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email Address</td>
                        <td>Validity to</td>


                    </tr>
                    <tr>
                        <td>
                            <div style="background-color: yellow;width:15px;">C</div>
                        </td>
                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email Address</td>
                        <td>Validity to</td>


                    </tr>
                    <tr>
                        <td>
                            <div style="background-color: red;width:15px;">P</div>
                        </td>
                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email Address</td>
                        <td>Validity to</td>


                    </tr>
                    <tr>
                        <td>
                            <div style="background-color: yellow;width:15px;">C</div>
                        </td>
                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email Address</td>
                        <td>Validity to</td>


                    </tr>


                </table>
            </div>


</div>