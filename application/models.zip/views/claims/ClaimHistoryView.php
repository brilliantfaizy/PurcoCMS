<?php $this->load->view('header'); ?>
<div id="content">

           <div id="innerMenu">
            
            <?php $this->load->view('claims/ClaimModalMenu'); ?>
        
        </div>

    <div class="FormFields">

        <form action="" method="post">
            
            <table class="FieldsTable"  cellpadding="6">
                <tr>
                    <td>Category:</td>
                    <td>
                        <select name="status" class="myfield"></select>
                    </td>
                </tr>
            </table>
            
        </form>

    </div>
    
    <div class="Grid">
                <table  cellspacing="0" cellpadding="10">

                    <tr>
                        <th></th>
                        <th>Date</th>
                        <th>Who</th>
                        <th>Subject</th>
                        <th>Description</th>
                        <th>Action</th>



                    </tr>

                    <tr>

                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email Address</td>
                        <td>Validity to</td>
                        <td>Validity to</td>
                        <td><a href="">Delete</a></td>


                    </tr>
                    <tr>

                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email Address</td>
                        <td>Validity to</td>
                        <td>Validity to</td>
                        <td><a href="">Delete</a></td>


                    </tr>
                    <tr>

                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email Address</td>
                        <td>Validity to</td>
                        <td>Validity to</td>
                        <td><a href="">Delete</a></td>


                    </tr>
                    <tr>

                        <td>First Name</td>
                        <td>Last Name</td>
                        <td>Email Address</td>
                        <td>Validity to</td>
                        <td>Validity to</td>
                        <td><a href="">Delete</a></td>


                    </tr>


                </table>
            </div>



</div>