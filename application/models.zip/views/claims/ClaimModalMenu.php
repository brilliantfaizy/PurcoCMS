<ul>
<li><a <?php echo $innerMenuActive=="overview" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/ClaimController/overview">Overview</a></li>
<li><a <?php echo $innerMenuActive=="journal" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/ClaimController/journal">Journal</a></li>
<li><a <?php echo $innerMenuActive=="involved" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/ClaimController/involved">Involved</a></li>
<li><a <?php echo $innerMenuActive=="amount" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/ClaimController/amount">Amounts</a></li>
<li><a <?php echo $innerMenuActive=="letter" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/ClaimController/letter">Letter</a></li>
<li><a <?php echo $innerMenuActive=="history" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/ClaimController/history">History</a></li>
<li><a <?php echo $innerMenuActive=="salvage" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/ClaimController/salvage">Salvages</a></li>
</ul>