<ul>
<li><a <?php echo $innerMenuActive=="calender" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/LibraryController/calender">Create Event</a></li>

</ul>