<?php $this->load->view('header'); ?>
<div id="content">
 <div id="innerMenu">

         <?php $this->load->view('employees/EmployeeTabs'); ?>

    </div>
<div id="innerTabs">
        
        
                <?php $this->load->view('employees/employeeinner'); ?>
                
                
     </div>
    <div class="FormFields">

        <form action="../insertallinfo" method="post">
            
            
            <table class="FieldsTable" cellpadding="6">
                <tr>
                    <th>Employee Detail</th>
                    <th></th>
                    <th></th>
                </tr>
                <tr>
                    <td></td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>Legal Name:</td>
                    <td>
                        <input class="myfield" placeholder="" name="legalname" type="text" />
                    </td>
                    
                    <td>Residential Address Line1:</td>
                    <td>
                        <input class="myfield" placeholder="" name="paddress1" type="text" />
                    </td>

                </tr>

                <tr>


                    <td>Residential Address Line2:</td>
                    <td>
                        <input class="myfield" placeholder="" name="paddress2" type="text" />
                    </td>
                    
                    <td>City:</td>
                    <td>
                        <input class="myfield" placeholder="" name="pcity" type="text" />
                    </td>
                </tr>

                <tr>
                    <td>State:</td>
                    <td>
                        <select name="pstate" class="myfield">
                        <option>select</option></select>
                    </td>
                    <td>Country:</td>
                    <td>  <select name="pcountry" class="myfield"><option>select</option></select></td>
                    



                </tr>

                <tr>
                <td>Zip:</td>
                    <td>
                        <input class="myfield" placeholder="" name="pzip" type="text" />
                    </td>
                    <td>Phone No.:</td>
                    <td>
                        <input class="myfield" placeholder="" name="pphn" type="text" />
                    </td>
                    
                   



                </tr>

                <tr>
                 <td>Mobile No.:</td>
                    <td>
                        <input class="myfield" placeholder="" name="pmobile" type="text" />
                    </td>
                    <td>Email Address:</td>
                    <td>
                        <input class="myfield" placeholder="" name="pemail" type="text" />
                    </td>
                    
                   



                </tr>

                <tr>
                 <td>Emergency Contact Name:</td>
                    <td>
                        <input class="myfield" placeholder="" name="emgcontactname" type="text" />
                    </td>
                    <td>Emergency Contact No.:</td>
                    <td>
                        <input class="myfield" placeholder="" name="Emgcontactno" type="text" />
                    </td>
                   
                    



                </tr>
                <tr>
                <td>Spouse:</td>
                    <td>
                        <input class="myfield" placeholder="" name="spouse" type="text" />
                    </td>
                    <td>Email Signature:</td>
                    <td>
                        <input class="myfield" placeholder="" name="emailsign" type="text" />
                    </td>


                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>

           
                <tr>
                    <th>Mailing Address</th>
                    <th></th>
                    <th></th>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>Phone No.:</td>
                    <td>
                        <input class="myfield" placeholder="" name="nphn" type="text" />
                    </td>
                   
                    <td>Fax No.:</td>
                    <td>
                        <input class="myfield" placeholder="" name="mfax" type="text" />
                    </td>

                </tr>

                <tr>
                    <td>Address Line1:</td>
                    <td>
                        <input class="myfield" placeholder="" name="maddress1" type="text" />
                    </td>
                    
                    <td>Address Line2:</td>
                    <td>
                        <input class="myfield" placeholder="" name="maddress2" type="text" />
                    </td>

                </tr>

                <tr>
                    <td>City:</td>
                    <td>
                        <input class="myfield" placeholder="" name="mcity" type="text" />
                    </td>
                   
                    <td>State:</td>
                    <td>
                        <select name="mstate" class="myfield"><option>select</option></select>
                    </td>



                </tr>
                <tr>
                <td>Country:</td>
                <td>  <select name="ncountry" class="myfield"><option>select</option></select></td>
                 <td>Zip:</td>
                    <td>
                        <input class="myfield" placeholder="" name="zipcode" type="text" />
                    </td>
                </tr>

                <tr>
                   
                    
                    <td>Email:</td>
                    <td>
                        <input class="myfield" placeholder="" name="memail" type="email" />
                    </td>


                </tr>

                <tr>


                    <td colspan="5">
                    <input type="hidden" name="Empid" value="<?php echo $Eid; ?>" />
                        <input class="button medium" type="submit" value="Save" />
                        <input class="button medium" style="margin-right: 13px;" type="reset" value="Cancel" />
                    </td>
                </tr>




            </table>
        </form>

    </div>
    
    
     



</div>

<?php $this->load->view('footer'); ?>