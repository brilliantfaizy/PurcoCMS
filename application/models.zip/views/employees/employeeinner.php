<ul>
<li <?php echo $innerTabsActive=="employeecreate" ? "class=\"innerTabsActive\"" : ""; ?>><a href="<?php echo $base; ?>/index.php/EmployeeController/employeecreate"><img src="<?php echo "$base/images/CreateIcon.png"; ?>" /><br />New</a></li>


</ul>