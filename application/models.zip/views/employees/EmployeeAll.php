<?php $this->load->view('header'); ?>
<div id="content">

 <div id="innerMenu">

         <?php $this->load->view('employees/EmployeeTabs'); ?>

    </div>

 <div id="innerTabs">
        
        
                <?php $this->load->view('employees/employeeinner'); ?>
                
                
     </div>


    <div class="Grid">
        
        <table cellspacing="0" cellpadding="10">

            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email Address</th>
                <th>Validity to</th>
                <th>Validity from</th>
                <th>Role</th>
                <th>Department</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <tr>
                <td>First Name</td>
                <td>Last Name</td>
                <td>Email Address</td>
                <td>Validity to</td>
                <td>Validity from</td>
                <td>Role</td>
                <td>Department</td>
                <td>Status</td>
                <td><a href="#" onclick="return false;">Eidt</a></td>
            </tr>

            <tr>
                <td>First Name</td>
                <td>Last Name</td>
                <td>Email Address</td>
                <td>Validity to</td>
                <td>Validity from</td>
                <td>Role</td>
                <td>Department</td>
                <td>Status</td>
                <td><a href="#" onclick="return false;">Eidt</a></td>
            </tr>

            <tr>
                <td>First Name</td>
                <td>Last Name</td>
                <td>Email Address</td>
                <td>Validity to</td>
                <td>Validity from</td>
                <td>Role</td>
                <td>Department</td>
                <td>Status</td>
                <td><a href="#" onclick="return false;">Eidt</a></td>
            </tr>

            <tr>
                <td>First Name</td>
                <td>Last Name</td>
                <td>Email Address</td>
                <td>Validity to</td>
                <td>Validity from</td>
                <td>Role</td>
                <td>Department</td>
                <td>Status</td>
                <td><a href="#" onclick="return false;">Eidt</a></td>
            </tr>

        </table>
    </div>

</div>

<?php $this->load->view('footer'); ?>