<ul>

<li><a <?php echo $innerMenuActive=="employeeall" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/EmployeeController/employeeall">View</a></li>

</ul>