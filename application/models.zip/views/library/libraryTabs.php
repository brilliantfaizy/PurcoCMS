<ul>
<li><a <?php echo $innerMenuActive=="search" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/LibraryController/search">Search</a></li>
<li><a href="<?php echo $base; ?>/index.php/LibraryController/search">Content</a></li>
<li><a href="<?php echo $base; ?>/index.php/LibraryController/search">Recent Changes</a></li>
<li><a href="<?php echo $base; ?>/index.php/LibraryController/search">Random Artical</a></li>
<li><a href="<?php echo $base; ?>/index.php/LibraryController/search">Tools</a></li>
<li><a href="<?php echo $base; ?>/index.php/LibraryController/search">Add Artical</a></li>
</ul>