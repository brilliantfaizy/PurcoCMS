<ul>
<li><a <?php echo $innerMenuActive=="create" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/ReportController/create">Create Report</a></li>
<li><a <?php echo $innerMenuActive=="import" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/ReportController/import">Import Reports</a></li>
<li><a <?php echo $innerMenuActive=="export" ? "class=\"innerMenuActive\"" : ""; ?> href="<?php echo $base; ?>/index.php/ReportController/export">Export All Reports</a></li>

</ul>