<?php

class EmployeeController extends CI_Controller{
    
    public $activeMenu = 'employees';
    
    function EmployeeController()
    {
        parent::__construct();
         $this->load->model('mainModel');
        $this->load->helper('url');
        $this->mainModel->checkSession();
        
    }
     
   function employee($id)
    {
      
        $data['base'] = $this->config->item('base_url');
        $data['css'] = $this->config->item('css');
        $data['innerMenuActive'] = 'employee';
        $data['innerTabsActive'] = 'employee';
        $data['Eid']=$id;
        $this->load->view('employees/Employee',$data);
      


    }
    
    function employeeall()
    {
      
        $data['base'] = $this->config->item('base_url');
        $data['css'] = $this->config->item('css');
        $data['innerTabsActive'] = '';
        $data['innerMenuActive'] = 'employeeall';
         

        $this->load->view('employees/employeeall',$data);
     
    }
    
    function system()
    {
      
        $data['base'] = $this->config->item('base_url');
        $data['css'] = $this->config->item('css');
        $data['innerTabsActive'] = 'system';
        $data['innerMenuActive'] = '';
        $this->load->view('employees/EmployeeSystem',$data);

    }
     function employeecreate()
    {
      
        $data['base'] = $this->config->item('base_url');
        $data['css'] = $this->config->item('css');
        $data['innerTabsActive'] = 'employeecreate';
        $data['innerMenuActive'] = '';
         $this->load->database();
        $this->load->model('EmployeeModel');
          $data['query']=$this->EmployeeModel->allrecord();
        $this->load->view('employees/EmployeeNew',$data);

    }
       
   function insert()
   {
        $this->load->model('mainModel');
       $this->load->helper('url');
       
        
        $data['base'] = $this->config->item('base_url');
        $data['css'] = $this->config->item('css');
      
        $this->load->database();
        $this->load->model('EmployeeModel');
        $EId=random_string('alnum',3);
        $a = $this->input->post('firstname');
        $b = $this->input->post('midname');
        $c = $this->input->post('lastname');
        $d = $this->input->post('loginname');
        $e = $this->input->post('password');
        $f = $this->input->post('email');
        
       
        $sql= "insert into tbl_employee_details
        (Firstname,Middlename,Lastname,ActiveStatus,Emp_Id,Password,LastModified,LoginName) 
        values('".$a."','".$b."','".$c."','0','".$EId."','".$e."',DATE_FORMAT(NOW(),'%Y-%m-%d %h:%i:%s'),'".$d."')";
    

        $this->db->query($sql);
        $id=$this->db->insert_id();
 
        $sql1="insert into tbl_user 
        (Username,Full_name,Password,Status,Email,CreationDate,DateModified,RId) 
        values('".$d."','".$a." ".$b." ".$c."','".$e."','0','".$f."',DATE_FORMAT(NOW(),'%Y-%m-%d %h:%i:%s'),DATE_FORMAT(NOW(),'%Y-%m-%d %h:%i:%s'),'010')";
        $this->db->query($sql1);
        echo "<script>alert('Added');</script>";
       
        
        redirect('EmployeeController/employeeall', 'refresh'); 
        // $this->load->view('RegAllView',$data);
        }
  
         function insertallinfo()
        {
         $this->load->model('mainModel');
         $this->load->helper('url');
         
        
        $data['base'] = $this->config->item('base_url');
        $data['css'] = $this->config->item('css');
      
        $this->load->database();
        //$this->load->model('EmployeeModel');
        $emp_id=$this->input->post('Empid');
        $a = $this->input->post('legalname');
        $b = $this->input->post('paddress1');
        $c = $this->input->post('paddress2');
        $d = $this->input->post('pcity');
        $e = $this->input->post('pstate');
        $w = $this->input->post('pcountry');
        $f = $this->input->post('pzip');
        $g = $this->input->post('pphn');
        $h = $this->input->post('pmobile');
        $i = $this->input->post('pemail');
        $j = $this->input->post('emgcontactname');
        $k = $this->input->post('Emgcontactno');
        $l = $this->input->post('spouse');
        $m = $this->input->post('emailsign');
        $n = $this->input->post('nphn');
        $o = $this->input->post('mfax');
        $p = $this->input->post('maddress1');
        $q = $this->input->post('maddress2');
        $r = $this->input->post('mcity');
        $s = $this->input->post('mstate');
        $t = $this->input->post('zipcode');
        $u = $this->input->post('memail');
       $v = $this->input->post('ncountry');
      $sql= "insert into tbl_employee_info
        (LegalName,Email,Emp_Id,EmergencyContactName,EmergencyContactNo,Spouse,EmailSignature,LastModified) 
        values('".$a."','".$i."','".$emp_id."','".$j."','".$k."','".$l."','".$m."',DATE_FORMAT(NOW(),'%Y-%m-%d %h:%i:%s'))";
    

        $this->db->query($sql);
        //$id=$this->db->insert_id();
 echo $sql."<br/>";
 
        $sql1="insert into tbl_contact_info 
        (Main_Id,Phone_no,Fax_no,Email_address) 
        values('".$emp_id."','".$n."',' ".$o."',' ".$u."')";
        $this->db->query($sql1);
        
       echo $sql1."<br/>";  
       
        $sql2="insert into tbl_address_all 
        (Main_Id,Address_name,Address1,Address2,City,State,Country,Postal_code,Last_modified) 
        values('".$emp_id."','Mailing Address','".$p."','".$q."','".$r."','".$s."','".$v."','".$t."',DATE_FORMAT(NOW(),'%Y-%m-%d %h:%i:%s'))";
        $this->db->query($sql2);
        
         echo $sql2."<br/>";
         
        $sql3="insert into tbl_address_all 
        (Main_Id,Address_name,Address1,Address2,City,State,Country,Postal_code,Last_modified) 
        values('".$emp_id."','Residential Address','".$b."','".$c."','".$d."','".$e."','".$w."','".$f."',DATE_FORMAT(NOW(),'%Y-%m-%d %h:%i:%s'))";
        $this->db->query($sql3);
        
        echo $sql3;
        
        echo "<script>alert('Added');</script>";
       
        
        redirect('EmployeeController/employeeall', 'refresh'); 
        // $this->load->view('RegAllView',$data);
      
    } 
              
           
           
          
   
}
?>