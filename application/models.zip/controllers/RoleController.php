<?php


class RoleController extends CI_Controller{
     public $activeMenu = 'RegController';
    function RoleController()
    {
        parent::__construct();
        $this->load->model('mainModel');
        $this->load->helper('url');
        $this->mainModel->checkSession();
    }
    
    function getall2() {
        
        $this->load->model('mainModel');
        $this->load->helper('url');
         
        
        $query['base'] = $this->config->item('base_url');
        $query['css'] = $this->config->item('css');
          $query['innerMenuActive'] = 'getall2';
        $this->load->database();
        $this->load->model('RoleModel');
  
        $q=$this->db->get('tbl_roles');
        $query['query']= $q->result();
        $this->load->view('managerole',$query);
        
       
       
     
  }
 

function insertview()
{
    $this->load->view('RoleInsertView'); 
}




function insert() {
    
   
    
    
    $this->load->database();
    $this->load->model('RoleModel');
    $this->load->library('form_validation');
    $this->form_validation->set_rules('roleid', 'Role Id', 'required|int');
    $this->form_validation->set_rules('roletitle', 'Role Title', 'required|min_length[5]|max_length[25]');
    $this->form_validation->set_rules('roledec', 'Role Description', 'required|min_length[5]');
    //$this->form_validation->set_rules('privileges', 'Privileges', 'required');
    
    
    if ($this->form_validation->run() == FALSE)
    {
      echo '<script>alert("Fill the data properly");</script>';
      $this->getall2();
    }
    else
    {
        $this->db->where('RoleTitle ', $this->input->post('roletitle'));
        $query1 = $this->db->get('tbl_roles');
        $this->db->where('RId ', $this->input->post('roleid'));
        $query = $this->db->get('tbl_roles');
        if($query->num_rows > 0 )
        { 
    
            echo "<script>alert('This Role Id already exists');</script>";
            $this->getall2();     
        }
         elseif($query1->num_rows > 0 )
        { 
    
            echo "<script>alert('This Role already exists');</script>";
            $this->getall2();     
        }
        else{
    //$this->load->library('form_validation');
     $data = array(
     'RId' => $this->input->post('roleid'),
     'RoleTitle' => $this->input->post('roletitle'),
     'Description' => $this->input->post('roledec')
    );

  $this->db->insert('tbl_roles',$data);
  //$this->load->view('myInsert');
  //return $this->db->insert_id();
  $this->getall2();
 }
  }
}
 
 
 
 function viewupdate(){
        $this->load->model('mainModel');
        $this->load->helper('url');
         
    
    $data['base'] = $this->config->item('base_url');
    $data['css'] = $this->config->item('css');
     $data['innerMenuActive'] = 'getall2';
    $id = $this->uri->segment(3);
    $this->load->model('RoleModel');

    $data['base'] = $this->config->item('base_url');
    $data['students']=$this->RoleModel->getall1();
    $data['single_student'] = $this->RoleModel->viewupdate($id);
    //print_r($this->RoleModel->viewupdate($id));
    $this->load->view('RoleUpdateView', $data);
   
    
 }

function viewupdate1(){
    $id = $this->uri->segment(3);
    $this->load->model('RoleModel');

    $data['base'] = $this->config->item('base_url');
    $data['students']=$this->RoleModel->getall1();
    $data['single_student'] = $this->RoleModel->viewupdate($id);

    $this->load->view('RoleDeleteView', $data);
    
 }
function update() {
   
        
    $this->load->database();
    $this->load->helper('url');
    $this->load->model('RoleModel');
    $id= $this->input->post('id');
     $this->load->library('form_validation');

$this->form_validation->set_rules('roletitle', 'Role Title', 'required|min_length[2]|max_length[15]');
$this->form_validation->set_rules('roledec', 'Role Description', 'required|min_length[5]');
if ($this->form_validation->run() == FALSE)
{
    echo '<script>alert("Fill the data properly");</script>';
   $this->load->view('RoleUpdateView');
  
}
else
{
    $data = array(
    'RoleTitle' => $this->input->post('roletitle'),
   'Description' => $this->input->post('roledec')
   

    );
    $this->RoleModel->update($id,$data);
    echo "<script> alert('Updated');</script>";
    $this->viewupdate();
 
}

redirect('RoleController/getall2');
}
 
function delete(){
    $this->load->helper('url');
    $this->load->database();
    $this->load->model('RoleModel');
    $id = $this->uri->segment(3);
    $this->RoleModel->delete($id);
    //$this->viewupdate1();
    redirect('RoleController/getall2');

}



}
?>