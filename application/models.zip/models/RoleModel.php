<?php

class RoleModel extends CI_Model{
    
     function RoleModel()
     {
        parent::__construct();
     }
     function getall2()
     {
       
        $query=$this->db->get($table);
        return $query->result();
     }
      
     
     function getall1()
     {
        $this->load->database();
        $query = $this->db->get('tbl_roles');
        return $query->result();
    }
    function get($table,$where=array(),$single=0)
    {
        $q=$this->db->get_where($table,$where);
        $result=$q->result_array();
        if($single)return $e[0];
        return $result;
    }
    function viewupdate($data)
    {    
         $this->load->database();
         $this->db->select('*');
         $this->db->from('tbl_roles');
         $this->db->where('RId', $data);
         $query = $this->db->get();
         $result = $query->result();
         return $result;
    }
 
    function update($id,$data)
    {
        $this->load->database();
        $this->db->where('RId', $id);
        $this->db->update('tbl_roles', $data);
    }
 
    function insert($table,$data)
    {
        $this->db->insert($table,$data);
        //return $this->db->insert_id();
    }
 
    function delete($id)
    {
        $this->db->where('RId', $id);
        $this->db->delete('tbl_roles');
    }
 
   
    
   
    }
    ?>
    