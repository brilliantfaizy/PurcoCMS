<?php

class EmployeeModel extends CI_Model{
    
     function EmployeeModel()
     {
        parent::__construct();
     }
      function getall()
     {
       
        $query=$this->db->get($table);
        return $query->result();
     }
     
      function insert($table)
    {
        $this->db->query($table);
      
    }
    
    function insertallinfo($table)
    {
        $this->db->query($table);
      
    }
      function allrecord()
     {
        $this->load->database();
      
                 $sql="SELECT tbl_employee_details.*, tbl_user.* FROM (tbl_employee_details INNER JOIN tbl_user 
                ON tbl_employee_details.LoginName= tbl_user.Username) ";
                $query=$this->db->query($sql);
                return $query->result();
     } 
        
}
?>
     